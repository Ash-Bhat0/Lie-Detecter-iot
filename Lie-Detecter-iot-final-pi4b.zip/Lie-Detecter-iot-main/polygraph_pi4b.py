#!/usr/bin/env python3
"""
Kinski Polygraph — Raspberry Pi 4 Model B adaptation (Optimized Real-Time Loop)
Based on NanoLieDetector.ino by Roni Bandini (2020).

Hardware assumptions:
- Analog pulse sensor -> MCP3008 CH0
- GSR measurement node -> MCP3008 CH1
- MCP3008 SPI CE0, powered at 3.3 V
- Pulse VU-meter driver input -> BCM GPIO18
- GSR VU-meter driver input -> BCM GPIO19
- Buzzer driver input -> BCM GPIO23

Pi 4B Real-Time Optimizations:
- Drift-compensated monotonic 500 Hz loop scheduling.
- Non-blocking buzzer state machine (never stalls ADC sampling during 10 ms alerts).
- Lazy-loaded background Fact-Checking & Domain Credibility worker (zero overhead
  when running with `--no-interactive`).
"""

import argparse
import math
import queue
import random
import sys
import threading
import time

# --- Hardware pins (BCM numbering) ---
PULSE_METER_GPIO = 18
GSR_METER_GPIO = 19
BUZZER_GPIO = 23

# --- MCP3008 channels ---
PULSE_CHANNEL = 0       # Arduino A0 equivalent
GSR_CHANNEL = 1         # Arduino A1 equivalent

# --- Values from the original sketch ---
THRESHOLD = 510
GALVANIC_COMPENSATION = 100
BPM_LIMIT = 180
SAMPLE_INTERVAL = 0.002  # target ~500 Hz sampling
REFRACTORY_PERIOD = 0.28 # reject implausibly close beat detections
GSR_READ_EVERY_N_BEATS = 3

# Arduino analogWrite() values are 0..255.
# gpiozero PWMOutputDevice.value is normalized 0.0..1.0.
PULSE_BEAT_PWM = 12
PULSE_REST_PWM = 2
METER_PWM_MAX = 255


class MockPWMDevice:
    def __init__(self, pin, frequency=1000, initial_value=0):
        self.pin = pin
        self.value = initial_value

    def close(self):
        pass


# Attempt to load gpiozero
try:
    from gpiozero import PWMOutputDevice
    pulse_meter = PWMOutputDevice(PULSE_METER_GPIO, frequency=1000, initial_value=0)
    gsr_meter = PWMOutputDevice(GSR_METER_GPIO, frequency=1000, initial_value=0)
    buzzer = PWMOutputDevice(BUZZER_GPIO, frequency=50, initial_value=0)
    HAS_GPIO = True
except Exception:
    pulse_meter = MockPWMDevice(PULSE_METER_GPIO)
    gsr_meter = MockPWMDevice(GSR_METER_GPIO)
    buzzer = MockPWMDevice(BUZZER_GPIO)
    HAS_GPIO = False

# Attempt to load spidev
HAS_SPI = False
spi = None
try:
    import spidev
    spi = spidev.SpiDev()
    spi.open(0, 0)  # SPI bus 0, CE0
    spi.max_speed_hz = 1_000_000
    HAS_SPI = True
except Exception:
    HAS_SPI = False


# Simulation state for mock mode
sim_phase = 0.0
sim_bpm = 72.0


def np_clip(val, low, high):
    return max(low, min(high, val))


def read_adc(channel: int) -> int:
    """Read MCP3008 channel 0..7, returning 0..1023."""
    global sim_phase
    if HAS_SPI and spi is not None:
        if not 0 <= channel <= 7:
            raise ValueError("MCP3008 channel must be between 0 and 7")
        response = spi.xfer2([1, (8 + channel) << 4, 0])
        return ((response[1] & 3) << 8) | response[2]
    if channel == PULSE_CHANNEL:
        freq = sim_bpm / 60.0
        sim_phase += 2.0 * math.pi * freq * SAMPLE_INTERVAL
        wave = math.sin(sim_phase) + 0.35 * math.sin(2.0 * sim_phase)
        return int(np_clip(512 + 200 * wave + random.uniform(-10, 10), 0, 1023))
    if channel == GSR_CHANNEL:
        return int(np_clip(450 + random.uniform(-15, 15), 0, 1023))
    return 0


def pwm_from_arduino(value: int) -> float:
    """Translate Arduino analogWrite 0..255 into gpiozero PWM 0..1."""
    return max(0.0, min(1.0, value / 255.0))


def beep_10ms() -> None:
    """Blocking 10 ms startup beep (used only once before the 500 Hz loop starts)."""
    buzzer.value = 0.5
    time.sleep(0.010)
    buzzer.value = 0


def estimate_physio_deception_prob(bpm: float, galvanic_val: int) -> float:
    """Lightweight live heuristic mapping instant BPM & GSR to a 0.0..1.0 arousal score."""
    bpm_component = max(0.0, min(1.0, (bpm - 72.0) / 45.0)) if bpm > 0 else 0.25
    gsr_component = max(0.0, min(1.0, (galvanic_val - 250.0) / 550.0))
    return max(0.05, min(0.95, 0.45 * bpm_component + 0.55 * gsr_component))


def _stdin_reader_thread(cmd_queue: "queue.Queue[str]", stop_event: threading.Event) -> None:
    """Daemon thread reading `Question | Answer` lines without ever blocking the sensor loop."""
    while not stop_event.is_set():
        try:
            line = sys.stdin.readline()
            if not line:
                break
            line = line.strip()
            if line:
                cmd_queue.put(line)
        except Exception:
            break


def main() -> None:
    parser = argparse.ArgumentParser(description="Kinski Polygraph Raspberry Pi 4B Hardware Monitor")
    parser.add_argument(
        "--no-interactive",
        action="store_true",
        help="Disable background CLI fact-check prompt (pure standalone hardware mode).",
    )
    args = parser.parse_args()

    beat_count = 0
    galvanic_val = 0
    galvanic_vu = 0
    last_beat_time = 0.0
    last_bpm = 72.0
    was_above_threshold = False
    pulse_baseline = 0.0
    baseline_initialized = False
    buzzer_off_at = 0.0

    interactive_enabled = (not args.no_interactive) and sys.stdin.isatty()
    cmd_queue: "queue.Queue[str]" = queue.Queue()
    stop_event = threading.Event()
    fact_worker = None
    format_credibility_table = None

    if interactive_enabled:
        from ml.fact_credibility_engine import (
            AsyncFactCheckWorker,
            FactCredibilityEngine,
            format_credibility_table as _fmt_table,
        )

        format_credibility_table = _fmt_table
        fact_worker = AsyncFactCheckWorker(FactCredibilityEngine())
        input_thread = threading.Thread(
            target=_stdin_reader_thread,
            args=(cmd_queue, stop_event),
            daemon=True,
            name="polygraph_cli_input",
        )
        input_thread.start()

    print("Kinski Polygraph started — Raspberry Pi 4 Model B")
    if not (HAS_SPI and HAS_GPIO):
        print("[Notice] Running in simulation/test mode (spidev/gpiozero hardware not detected).")
    print(f"Pulse threshold: {THRESHOLD}")
    if interactive_enabled:
        print(
            "[Live Fact-Check Hook Active] Type 'Question | Subject Answer' + Enter at any time "
            "(or 'table' to view credibility, 'reset' to clear session)."
        )
    print("Press Ctrl+C to stop.")
    print("Note: this is an experimental physiological-response device, not a lie detector.")

    # Startup needle sweep, matching original sketch's 0..19 sweep.
    for value in range(20):
        pulse_meter.value = pwm_from_arduino(value)
        gsr_meter.value = pwm_from_arduino(value)
        time.sleep(0.050)
    pulse_meter.value = 0
    gsr_meter.value = 0
    beep_10ms()

    next_tick = time.monotonic()

    try:
        while True:
            now = time.monotonic()

            # Non-blocking buzzer shutoff (avoids dropping 500 Hz samples during alerts)
            if buzzer_off_at > 0.0 and now >= buzzer_off_at:
                buzzer.value = 0
                buzzer_off_at = 0.0

            pulse_raw = read_adc(PULSE_CHANNEL)

            if not baseline_initialized:
                pulse_baseline = float(pulse_raw)
                baseline_initialized = True
            else:
                pulse_baseline += 0.01 * (pulse_raw - pulse_baseline)

            above = pulse_raw >= THRESHOLD
            beat_detected = (
                above
                and not was_above_threshold
                and (now - last_beat_time) >= REFRACTORY_PERIOD
            )
            was_above_threshold = above

            if beat_detected:
                interval = now - last_beat_time if last_beat_time else 0
                last_beat_time = now
                bpm = (60.0 / interval) if interval > 0 else 0.0

                if bpm < BPM_LIMIT:
                    last_bpm = bpm
                    beat_count += 1
                    pulse_meter.value = pwm_from_arduino(PULSE_BEAT_PWM)

                    if beat_count >= GSR_READ_EVERY_N_BEATS:
                        galvanic_val = read_adc(GSR_CHANNEL) - GALVANIC_COMPENSATION
                        beat_count = 0

                    if galvanic_val > 0:
                        galvanic_vu = max(0, min(20, int((galvanic_val * 20) / 1024)))
                    else:
                        galvanic_vu = 0

                    gsr_meter.value = pwm_from_arduino(galvanic_vu)

                    print(
                        f"Beat detected | BPM: {bpm:5.1f} | "
                        f"Galvanic: {galvanic_val:4d} | "
                        f"GSR meter: {galvanic_vu:2d}"
                    )

                    if galvanic_val > 800:
                        buzzer.value = 0.5
                        buzzer_off_at = now + 0.010

            # Non-blocking poll of interactive CLI input & completed background fact-checks
            if fact_worker is not None:
                try:
                    raw_cmd = cmd_queue.get_nowait()
                    low = raw_cmd.lower()
                    if low == "table":
                        print("\n[Domain Credibility Table]")
                        print(format_credibility_table(fact_worker.engine.tracker.get_domain_table()))
                    elif low == "reset":
                        fact_worker.engine.reset_session()
                        print("\n[Session Credibility Reset]")
                    elif "|" in raw_cmd:
                        q_part, a_part = raw_cmd.split("|", 1)
                        p_phys = estimate_physio_deception_prob(last_bpm, galvanic_val)
                        fact_worker.submit_evaluation(q_part.strip(), a_part.strip(), p_phys)
                        print(f"\n[Fact-Check Queued in Background] Q: {q_part.strip()} | A: {a_part.strip()}")
                    else:
                        print("\n[Format Hint] Use: Question | Subject Answer (e.g., What is 1+1? | 3)")
                except queue.Empty:
                    pass

                for res in fact_worker.poll_completed():
                    fc = res.fact_check
                    print("\n" + "=" * 64)
                    print(f"[FUSED POLYGRAPH RESULT] {res.final_verdict}")
                    print(
                        f"  Deception: {res.final_deception_pct:.1f}% | "
                        f"Truth: {res.final_truth_pct:.1f}% | "
                        f"Physio: {res.physio_deception_pct:.1f}%"
                    )
                    print(
                        f"  Topic: {fc.topic} | Factual: {fc.factual_verdict} "
                        f"({fc.verification_source}, conf={fc.factual_confidence:.2f})"
                    )
                    print(f"  Fact Summary: {fc.correct_fact_summary}")
                    print(f"  Credibility : {res.credibility_note}")
                    print("=" * 64)
                    if res.final_deception_pct >= 65.0:
                        gsr_meter.value = pwm_from_arduino(20)
                        buzzer.value = 0.5
                        buzzer_off_at = now + 0.015

            pulse_meter.value = pwm_from_arduino(
                PULSE_BEAT_PWM if beat_detected else PULSE_REST_PWM
            )

            # Drift-compensated 500 Hz sleep
            next_tick += SAMPLE_INTERVAL
            sleep_for = next_tick - time.monotonic()
            if sleep_for > 0:
                time.sleep(sleep_for)
            elif sleep_for < -0.05:
                next_tick = time.monotonic()

    except KeyboardInterrupt:
        print("\nStopping.")
    finally:
        stop_event.set()
        if fact_worker is not None:
            fact_worker.shutdown()
        pulse_meter.value = 0
        gsr_meter.value = 0
        buzzer.value = 0
        if HAS_SPI and spi is not None:
            spi.close()


if __name__ == "__main__":
    try:
        main()
    finally:
        pulse_meter.close()
        gsr_meter.close()
        buzzer.close()
