#!/usr/bin/env python3
"""
Local & Keyless Fact-Checking + Domain Credibility Engine (Raspberry Pi 4B Optimized)
=====================================================================================
Target Hardware: Raspberry Pi 4 Model B (ARM64, CPU-only, limited RAM, microSD storage).
Zero API Keys / 100% Free / Non-Blocking for Real-Time Sensor Loops.

Pi 4B Optimizations:
  - Lazy SymPy import: saves ~45 MB RAM and ~1 s cold boot until math verification is needed.
  - Pre-compiled regexes & LRU-cached tokenization for sub-millisecond classification.
  - Two-tier cache (in-memory LRU + SQLite WAL mode) to minimize microSD wear and latency.
  - HTTP connection pooling + early-exit Tier-2 web lookups with strict timeouts.
  - Unified fusion core shared by sync and background worker paths.
"""

from __future__ import annotations

import concurrent.futures
import difflib
import hashlib
import json
import math
import queue
import re
import sqlite3
import threading
import time
from collections import OrderedDict
from dataclasses import asdict, dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
from requests.adapters import HTTPAdapter

# Optional Pi-friendly libraries with graceful stdlib fallbacks
try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity as sk_cosine_similarity

    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False

try:
    from rapidfuzz import fuzz as rf_fuzz

    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False

try:
    from ddgs import DDGS

    HAS_DDGS = True
except ImportError:
    HAS_DDGS = False

# Lazy-loaded SymPy state (loaded once on first math verification to keep cold-start lean)
_SYMPY_MOD = None
_SYMPY_PARSE = None
_SYMPY_TRANSFORMS = None
_SYMPY_ALLOWED_LOCALS = None
_SYMPY_LOCK = threading.Lock()


def _ensure_sympy():
    """Lazy-imports SymPy on first math query to avoid ~45 MB RAM overhead on non-math runs."""
    global _SYMPY_MOD, _SYMPY_PARSE, _SYMPY_TRANSFORMS, _SYMPY_ALLOWED_LOCALS
    if _SYMPY_MOD is not None:
        return _SYMPY_MOD, _SYMPY_PARSE, _SYMPY_TRANSFORMS, _SYMPY_ALLOWED_LOCALS
    with _SYMPY_LOCK:
        if _SYMPY_MOD is None:
            import sympy as sp
            from sympy.parsing.sympy_parser import (
                convert_xor,
                implicit_multiplication_application,
                parse_expr,
                standard_transformations,
            )

            _SYMPY_MOD = sp
            _SYMPY_PARSE = parse_expr
            _SYMPY_TRANSFORMS = standard_transformations + (
                implicit_multiplication_application,
                convert_xor,
            )
            _SYMPY_ALLOWED_LOCALS = {
                "sqrt": sp.sqrt,
                "pi": sp.pi,
                "abs": sp.Abs,
                "sin": sp.sin,
                "cos": sp.cos,
                "tan": sp.tan,
                "log": sp.log,
            }
    return _SYMPY_MOD, _SYMPY_PARSE, _SYMPY_TRANSFORMS, _SYMPY_ALLOWED_LOCALS


# =============================================================================
# TUNABLE CONFIGURATION (Single Place to Tune Weights, Timeouts, and Switches)
# =============================================================================
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CACHE_DB = PROJECT_ROOT / "data" / "fact_cache.db"
DEFAULT_SESSION_LOG_DIR = PROJECT_ROOT / "data" / "credibility_sessions"


@dataclass
class FactCredibilityConfig:
    """All tunable fusion weights, credibility dynamics, and lookup settings."""

    # --- Optional Local Tiny-LLM Hook (OFF by default) ---
    USE_LOCAL_OLLAMA: bool = False
    OLLAMA_URL: str = "http://localhost:11434/api/generate"
    OLLAMA_MODEL: str = "qwen3:1.7b"
    OLLAMA_TIMEOUT_SEC: float = 6.0

    # --- Keyless Web Lookup & Two-Tier Cache ---
    ENABLE_WEB_LOOKUP: bool = True
    WEB_TIMEOUT_SEC: float = 4.5
    CACHE_DB_PATH: Path = DEFAULT_CACHE_DB
    CACHE_TTL_SECONDS: int = 7 * 24 * 3600  # 7 days
    CACHE_MEMORY_MAX_ITEMS: int = 256
    USER_AGENT: str = "KinskiIoTPolygraph/2.1 (RaspberryPi4B; Educational Keyless FactCheck)"

    # --- Fused Deception Meter Weights ---
    WEIGHT_PHYSIO_OBJECTIVE: float = 0.35
    WEIGHT_FACTUAL_OBJECTIVE: float = 0.65
    WEIGHT_PHYSIO_SUBJECTIVE: float = 1.00

    # --- Domain Credibility Dynamics (Bounded Exponential Penalty & Gradual Recovery) ---
    BASE_LIE_PENALTY: float = 0.35
    LIE_COMPOUND_FACTOR: float = 1.40
    TRUTH_RECOVERY_STEP: float = 0.16
    MAX_DOMAIN_DECEPTION_BIAS: float = 0.25
    MAX_DOMAIN_TRUST_RELIEF: float = 0.10
    GLOBAL_CREDIBILITY_WEIGHT: float = 0.04

    # --- Verdict Thresholds (Deception %) ---
    DECEPTION_HIGH_THRESHOLD: float = 65.0
    DECEPTION_MED_THRESHOLD: float = 45.0

    # --- Optional Session Logging ---
    LOG_SESSIONS: bool = False
    SESSION_LOG_DIR: Path = DEFAULT_SESSION_LOG_DIR


# =============================================================================
# STRUCTURED RESULT DATACLASSES
# =============================================================================
@dataclass
class FactCheckResult:
    """Output of the local classifier + tiered keyless fact-checker."""

    is_objective: bool
    topic: str
    related_keywords: List[str]
    factual_verdict: str  # "TRUE", "FALSE", "UNVERIFIABLE", "SUBJECTIVE"
    factual_confidence: float
    correct_fact_summary: str
    verification_source: str  # "sympy", "wikipedia", "duckduckgo_ia", "ddgs", "ollama_refined", "offline_fallback", "none"
    sources: List[str] = field(default_factory=list)
    latency_ms: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class FusedEvaluationResult:
    """Complete transparent breakdown of Physiological + Factual + Domain Credibility."""

    question: str
    subject_answer: str
    fact_check: FactCheckResult

    physio_deception_pct: float
    factual_deception_pct: Optional[float]
    domain_credibility_before: float
    domain_credibility_after: float
    domain_bias_pct: float
    global_bias_pct: float
    total_credibility_bias_pct: float
    credibility_note: str

    final_deception_pct: float
    final_truth_pct: float
    final_verdict: str

    domain_table: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["fact_check"] = self.fact_check.to_dict()
        return data


# =============================================================================
# PRE-COMPILED REGEXES & FAST TEXT UTILITIES
# =============================================================================
_STOPWORDS = frozenset(
    {
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
        "do", "does", "did", "have", "has", "had", "what", "which", "who",
        "whom", "whose", "where", "when", "why", "how", "in", "on", "at",
        "to", "for", "of", "with", "by", "from", "about", "as", "into",
        "that", "this", "these", "those", "it", "its", "and", "or", "but",
        "if", "then", "than", "so", "can", "could", "would", "should",
        "will", "shall", "may", "might", "much", "many", "very", "just",
        "tell", "me", "please", "true", "false", "yes", "no",
    }
)

_RE_TOKEN = re.compile(r"[a-z0-9]+")
_RE_WHITESPACE = re.compile(r"\s+")
_RE_HTML_TAG = re.compile(r"<[^>]+>")
_RE_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+")
_RE_NUMBER_TOKEN = re.compile(r"-?\d+(?:\.\d+)?(?:\s*/\s*\d+(?:\.\d+)?)?")
_RE_FLOAT_TOKEN = re.compile(r"-?\d+(?:\.\d+)?")
_RE_SAFE_MATH_CHARS = re.compile(r"[^0-9a-zA-Z\+\-\*\/\.\(\)\s\^]")
_RE_MATH_WORD_TOKENS = re.compile(r"[a-z]+|\d+\.\d+|\d+|[^\s\w]")
_RE_MATH_LEAD_IN = re.compile(
    r"\b(what|is|are|does|do|calculate|compute|evaluate|the|value|of|answer|to|tell|me)\b"
)
_RE_PCT_PATTERN = re.compile(r"(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)")
_RE_COMP_PATTERN = re.compile(
    r"([0-9\.\(\)\+\-\*\/\^\ssqrt]+?)\s*(==|!=|>=|<=|=|>|<)\s*([0-9\.\(\)\+\-\*\/\^\ssqrt]+)"
)
_RE_EXPR_PATTERN = re.compile(
    r"(?:sqrt\s*\(\s*[0-9\.\+\-\*\/\s]+\s*\)|-?\d+(?:\.\d+)?(?:\s*[\+\-\*\/\^]\s*-?\d+(?:\.\d+)?)+)"
)
_RE_YES_WORDS = re.compile(r"\b(yes|yeah|yep|yup|true|correct|right|affirmative|indeed)\b")
_RE_YES_NEG = re.compile(r"\b(not true|not right|not correct|no)\b")
_RE_NO_WORDS = re.compile(r"\b(no|nope|nah|false|incorrect|wrong|negative)\b")
_RE_QUERY_PREFIX = re.compile(
    r"^(what is|what was|who is|who was|where is|when did|when was|tell me|can you tell me)\s+",
    re.I,
)
_RE_YN_QUESTION = re.compile(r"^\s*(is|are|was|were|does|do|did|can|has|have)\b", re.I)
_RE_NEG_CUES = re.compile(
    r"\b(not|never|no longer|false|myth|incorrect|contrary|misconception|unlike)\b"
)
_RE_NUMERIC_Q = re.compile(
    r"\b(how many|what year|when|boiling|freezing|temperature|how tall|how far|speed)\b", re.I
)
_RE_KNOW_WH = re.compile(r"\b(do you know|can you tell me)\s+(what|who|where|when|how)\b", re.I)
_RE_WH_FALLBACK = re.compile(r"^\s*(what|who|where|when|which|how many|is|are)\b", re.I)

_WORD_MATH_REPLACEMENTS = [
    (re.compile(r"\bmultiplied by\b"), " * "),
    (re.compile(r"\bdivided by\b"), " / "),
    (re.compile(r"\bis equal to\b"), " = "),
    (re.compile(r"\bequal to\b"), " = "),
    (re.compile(r"\bequals\b"), " = "),
    (re.compile(r"\bplus\b"), " + "),
    (re.compile(r"\bminus\b"), " - "),
    (re.compile(r"\btimes\b"), " * "),
    (re.compile(r"\bover\b"), " / "),
    (re.compile(r"\bsquare root of\s+([a-z0-9\.]+)"), r"sqrt(\1)"),
    (re.compile(r"\b([a-z0-9\.]+)\s+squared\b"), r"(\1)**2"),
    (re.compile(r"\b([a-z0-9\.]+)\s+cubed\b"), r"(\1)**3"),
    (re.compile(r"\bgreater than or equal to\b"), " >= "),
    (re.compile(r"\bless than or equal to\b"), " <= "),
    (re.compile(r"\bgreater than\b"), " > "),
    (re.compile(r"\bless than\b"), " < "),
    (re.compile(r"×"), " * "),
    (re.compile(r"÷"), " / "),
]


def _clean_zero(val: float, digits: int = 1) -> float:
    """Rounds float and eliminates negative zero (-0.0 -> 0.0)."""
    return round(val, digits) + 0.0


def _tokenize(text: str) -> List[str]:
    return _RE_TOKEN.findall(text.lower())


@lru_cache(maxsize=512)
def _extract_keywords_cached(text: str, max_keywords: int = 8) -> Tuple[str, ...]:
    tokens = _tokenize(text)
    seen = set()
    keywords = []
    for tok in tokens:
        if len(tok) > 1 and tok not in _STOPWORDS and tok not in seen:
            seen.add(tok)
            keywords.append(tok)
            if len(keywords) >= max_keywords:
                break
    return tuple(keywords)


def _extract_keywords(text: str, max_keywords: int = 8) -> List[str]:
    return list(_extract_keywords_cached(text, max_keywords))


def _fuzzy_ratio(a: str, b: str) -> float:
    """Returns 0.0..1.0 token-set similarity using rapidfuzz if installed, else difflib."""
    a_clean = _RE_WHITESPACE.sub(" ", a.lower().strip())
    b_clean = _RE_WHITESPACE.sub(" ", b.lower().strip())
    if not a_clean or not b_clean:
        return 0.0
    if HAS_RAPIDFUZZ:
        return max(
            rf_fuzz.token_set_ratio(a_clean, b_clean),
            rf_fuzz.partial_ratio(a_clean, b_clean),
        ) / 100.0
    seq = difflib.SequenceMatcher(None, a_clean, b_clean).ratio()
    a_toks = set(_tokenize(a_clean))
    b_toks = set(_tokenize(b_clean))
    if a_toks and b_toks:
        overlap = len(a_toks & b_toks) / max(1, min(len(a_toks), len(b_toks)))
        return max(seq, overlap)
    return seq


def _tfidf_cosine_scores(query: str, documents: List[str]) -> List[float]:
    """Computes cosine similarity between query and each document (sklearn or stdlib fallback)."""
    if not documents:
        return []
    if HAS_SKLEARN:
        try:
            vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
            mat = vec.fit_transform([query] + documents)
            sims = sk_cosine_similarity(mat[0:1], mat[1:]).flatten()
            return [float(s) for s in sims]
        except ValueError:
            return [0.0] * len(documents)

    all_docs = [_tokenize(query)] + [_tokenize(d) for d in documents]
    df: Dict[str, int] = {}
    for toks in all_docs:
        for t in set(toks):
            df[t] = df.get(t, 0) + 1
    n_docs = len(all_docs)

    def to_vec(toks: List[str]) -> Dict[str, float]:
        tf: Dict[str, float] = {}
        for t in toks:
            tf[t] = tf.get(t, 0.0) + 1.0
        return {
            t: count * (math.log((n_docs + 1.0) / (df.get(t, 0) + 1.0)) + 1.0)
            for t, count in tf.items()
        }

    q_vec = to_vec(all_docs[0])
    q_norm = math.sqrt(sum(v * v for v in q_vec.values()))
    if q_norm == 0.0:
        return [0.0] * len(documents)

    scores = []
    for toks in all_docs[1:]:
        d_vec = to_vec(toks)
        d_norm = math.sqrt(sum(v * v for v in d_vec.values()))
        if d_norm == 0.0:
            scores.append(0.0)
            continue
        dot = sum(q_vec[t] * d_vec.get(t, 0.0) for t in q_vec)
        scores.append(dot / (q_norm * d_norm))
    return scores


# =============================================================================
# 1. LIGHTWEIGHT LOCAL QUESTION CLASSIFIER & TOPIC TAGGER (<5 ms on Pi 4B)
# =============================================================================
_DOMAIN_CORPUS: Dict[str, str] = {
    "mathematics": (
        "add subtract multiply divide sum difference product quotient equals plus minus "
        "times squared cubed square root percentage fraction equation algebra geometry "
        "prime number integer decimal calculate solve arithmetic math pi radius area"
    ),
    "geography": (
        "capital city country continent ocean river mountain desert border population "
        "island state province located latitude longitude map europe asia africa america "
        "france paris japan tokyo india delhi mount everest nile amazon"
    ),
    "science": (
        "planet solar system earth mars sun moon gravity atom molecule element chemical "
        "symbol periodic table oxygen hydrogen water boiling point freezing temperature "
        "biology cell dna physics speed of light electricity magnet evolution species"
    ),
    "history": (
        "war president king queen empire century year invented discovered founded "
        "independence revolution treaty ancient roman egypt world war moon landing "
        "apollo constitution historical figure assassination"
    ),
    "general_knowledge": (
        "author wrote book movie film director sport olympics championship currency "
        "language flag company founder ceo tallest largest fastest smallest record "
        "award nobel prize music instrument painting artist"
    ),
    "personal": (
        "you your yourself my mine did you take did you steal have you ever were you "
        "do you think do you like favorite opinion feel feeling personal secret "
        "money wallet yesterday last night home work friend family relationship"
    ),
}

_SUBJECTIVE_PATTERNS = [
    re.compile(r"\b(did you|have you|were you|are you|do you|would you|will you|can you)\b", re.I),
    re.compile(r"\b(your|yourself|you ever|in your opinion|do you think|do you believe|how do you feel)\b", re.I),
    re.compile(r"\b(my |mine |our |tell me about yourself)\b", re.I),
]

_MATH_PATTERNS = [
    re.compile(r"\d+\s*[\+\-\*\/\^×÷=<>]\s*\d+"),
    re.compile(
        r"\b(plus|minus|times|multiplied by|divided by|square root|squared|cubed|"
        r"equals|equal to|percent of|sum of|product of|remainder|modulo|solve)\b",
        re.I,
    ),
    re.compile(r"\bwhat is\s+[a-z0-9\s\.\(\)]+\s*(plus|minus|times|divided|over|\+|\-|\*|\/)", re.I),
]

_OBJECTIVE_STEMS = [
    re.compile(r"^\s*(what is the|who is|who was|who invented|who wrote|who discovered)\b", re.I),
    re.compile(r"^\s*(when did|when was|where is|where was|how many|how tall|how far|how old is)\b", re.I),
    re.compile(r"^\s*(is |are |does |do |was |were ).*\b(capital|planet|element|country|river|ocean|war|boiling|freezing)\b", re.I),
    re.compile(r"^\s*(is|does)\s+\d+", re.I),
]


class LocalQuestionClassifier:
    """Fast (<5 ms) hybrid classifier: pre-compiled intent rules + TF-IDF topic taxonomy."""

    def __init__(self) -> None:
        self._topics = list(_DOMAIN_CORPUS.keys())
        self._corpus_texts = [_DOMAIN_CORPUS[t] for t in self._topics]
        self._vectorizer = None
        self._corpus_matrix = None
        if HAS_SKLEARN:
            self._vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
            self._corpus_matrix = self._vectorizer.fit_transform(self._corpus_texts)

    def classify(self, question: str, subject_answer: str = "") -> Tuple[bool, str, List[str]]:
        """Returns (is_objective, normalized_topic, related_keywords)."""
        q_clean = question.strip()
        combined = f"{q_clean} {subject_answer}".strip()
        keywords = _extract_keywords(q_clean)

        # 1. Strong Math detection (always objective)
        if any(p.search(q_clean) for p in _MATH_PATTERNS):
            return True, "mathematics", keywords or ["math"]

        # 2. Strong Personal / Subjective detection
        has_subjective_cue = any(p.search(q_clean) for p in _SUBJECTIVE_PATTERNS)
        has_objective_stem = any(p.search(q_clean) for p in _OBJECTIVE_STEMS)

        if has_subjective_cue and not has_objective_stem:
            if _RE_KNOW_WH.search(q_clean):
                has_subjective_cue = False
            else:
                return False, "personal", keywords or ["personal"]

        # 3. TF-IDF topic similarity against curated taxonomy
        if HAS_SKLEARN and self._vectorizer is not None and self._corpus_matrix is not None:
            q_vec = self._vectorizer.transform([combined])
            sims = sk_cosine_similarity(q_vec, self._corpus_matrix).flatten()
            best_idx = int(sims.argmax())
            best_score = float(sims[best_idx])
            best_topic = self._topics[best_idx]
        else:
            sims = _tfidf_cosine_scores(combined, self._corpus_texts)
            best_idx = max(range(len(sims)), key=lambda i: sims[i]) if sims else 0
            best_score = sims[best_idx] if sims else 0.0
            best_topic = self._topics[best_idx]

        if best_topic == "personal" and best_score >= 0.08 and not has_objective_stem:
            return False, "personal", keywords or ["personal"]

        if best_score >= 0.05:
            return (best_topic != "personal"), best_topic, keywords or [best_topic]

        if has_objective_stem or _RE_WH_FALLBACK.match(q_clean):
            return True, "general_knowledge", keywords or ["general"]

        return False, "personal", keywords or ["personal"]


# =============================================================================
# 2. TWO-TIER CACHE: IN-MEMORY LRU + SQLITE WAL (SD-Card Friendly)
# =============================================================================
class FactCache:
    """Thread-safe in-memory LRU + SQLite WAL cache to minimize SD-card wear on Pi 4B."""

    def __init__(
        self,
        db_path: Path,
        ttl_seconds: int = 7 * 24 * 3600,
        mem_max_items: int = 256,
    ) -> None:
        self.db_path = Path(db_path)
        self.ttl_seconds = ttl_seconds
        self.mem_max_items = mem_max_items
        self._lock = threading.Lock()
        self._mem: "OrderedDict[str, Tuple[float, Dict[str, Any]]]" = OrderedDict()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.db_path, timeout=5.0, check_same_thread=False)
        self._init_db()

    def _init_db(self) -> None:
        with self._lock:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS fact_cache (
                    query_key TEXT PRIMARY KEY,
                    normalized_query TEXT NOT NULL,
                    source TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at REAL NOT NULL
                )
                """
            )
            self._conn.commit()

    @staticmethod
    def _make_key(query: str) -> Tuple[str, str]:
        norm = _RE_WHITESPACE.sub(" ", query.lower().strip())
        return hashlib.sha256(norm.encode("utf-8")).hexdigest(), norm

    def get(self, query: str) -> Optional[Dict[str, Any]]:
        key, _ = self._make_key(query)
        now = time.time()
        with self._lock:
            # Fast L1 in-memory LRU hit (zero disk I/O)
            mem_entry = self._mem.get(key)
            if mem_entry is not None:
                created_at, payload = mem_entry
                if (now - created_at) <= self.ttl_seconds:
                    self._mem.move_to_end(key)
                    return dict(payload)
                del self._mem[key]

            # L2 SQLite lookup
            try:
                row = self._conn.execute(
                    "SELECT source, payload_json, created_at FROM fact_cache WHERE query_key = ?",
                    (key,),
                ).fetchone()
                if not row:
                    return None
                source, payload_json, created_at = row
                if (now - float(created_at)) > self.ttl_seconds:
                    return None
                payload = json.loads(payload_json)
                payload["cached"] = True
                payload["source"] = source
                self._mem_put_locked(key, float(created_at), payload)
                return dict(payload)
            except Exception:
                return None

    def _mem_put_locked(self, key: str, created_at: float, payload: Dict[str, Any]) -> None:
        self._mem[key] = (created_at, dict(payload))
        self._mem.move_to_end(key)
        while len(self._mem) > self.mem_max_items:
            self._mem.popitem(last=False)

    def set(self, query: str, source: str, payload: Dict[str, Any]) -> None:
        key, norm = self._make_key(query)
        now = time.time()
        stored = dict(payload)
        stored["cached"] = True
        stored["source"] = source
        with self._lock:
            self._mem_put_locked(key, now, stored)
            try:
                self._conn.execute(
                    """
                    INSERT OR REPLACE INTO fact_cache
                    (query_key, normalized_query, source, payload_json, created_at)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (key, norm, source, json.dumps(payload), now),
                )
                self._conn.commit()
            except Exception:
                pass

    def count(self) -> int:
        with self._lock:
            try:
                row = self._conn.execute("SELECT COUNT(*) FROM fact_cache").fetchone()
                return int(row[0]) if row else 0
            except Exception:
                return len(self._mem)

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except Exception:
                pass


# =============================================================================
# 3. TIERED KEYLESS FACT-CHECKING ENGINE (SymPy -> Web -> Local Verifier)
# =============================================================================
_WORD_NUMBERS: Dict[str, int] = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
    "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19,
    "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50,
    "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90,
}

_SCALES: Dict[str, int] = {
    "hundred": 100,
    "thousand": 1000,
    "million": 1_000_000,
}


def _words_to_numbers(text: str) -> str:
    """Converts common English number words and math operators into symbolic math tokens."""
    s = text.lower()
    for pat, repl in _WORD_MATH_REPLACEMENTS:
        s = pat.sub(repl, s)

    tokens = _RE_MATH_WORD_TOKENS.findall(s)
    out: List[str] = []
    i = 0
    n_toks = len(tokens)
    while i < n_toks:
        tok = tokens[i]
        if tok in _WORD_NUMBERS or tok in _SCALES:
            total = 0
            current = 0
            j = i
            while j < n_toks and (
                tokens[j] in _WORD_NUMBERS or tokens[j] in _SCALES or tokens[j] == "and"
            ):
                w = tokens[j]
                if w == "and":
                    j += 1
                    continue
                if w in _WORD_NUMBERS:
                    current += _WORD_NUMBERS[w]
                elif w == "hundred":
                    current = (current or 1) * 100
                elif w in _SCALES:
                    total += (current or 1) * _SCALES[w]
                    current = 0
                j += 1
            out.append(str(total + current))
            i = j
        else:
            out.append(tok)
            i += 1
    return " ".join(out)


def _extract_numeric_value(text: str) -> Optional[float]:
    """Extracts a single numeric value from an answer string (digits, fractions, or number words)."""
    converted = _words_to_numbers(text)
    match = _RE_NUMBER_TOKEN.search(converted)
    if not match:
        return None
    token = match.group(0).replace(" ", "")
    if "/" not in token:
        try:
            return float(token)
        except ValueError:
            return None
    try:
        num_str, den_str = token.split("/", 1)
        den = float(den_str)
        return float(num_str) / den if abs(den) > 1e-12 else None
    except Exception:
        return None


def _parse_yes_no(answer: str) -> Optional[bool]:
    a = answer.strip().lower()
    if _RE_YES_WORDS.search(a):
        return False if _RE_YES_NEG.search(a) else True
    if _RE_NO_WORDS.search(a):
        return False
    return None


def _safe_sympy_eval(expr_str: str) -> Optional[float]:
    """Safely evaluates a math expression using lazy-loaded SymPy (strictly no raw eval())."""
    cleaned = _RE_SAFE_MATH_CHARS.sub("", expr_str).strip()
    if not cleaned:
        return None
    sp, parse_expr, transforms, allowed_locals = _ensure_sympy()
    try:
        expr = parse_expr(
            cleaned,
            local_dict=allowed_locals,
            transformations=transforms,
            evaluate=True,
        )
        if expr.free_symbols:
            return None
        return float(sp.N(expr))
    except Exception:
        return None


class KeylessFactChecker:
    """Tiered keyless fact-checker: SymPy -> Wikipedia/DDG/ddgs -> Local Verifier (+ optional Ollama)."""

    def __init__(self, config: Optional[FactCredibilityConfig] = None) -> None:
        self.config = config or FactCredibilityConfig()
        self.classifier = LocalQuestionClassifier()
        self.cache = FactCache(
            self.config.CACHE_DB_PATH,
            self.config.CACHE_TTL_SECONDS,
            self.config.CACHE_MEMORY_MAX_ITEMS,
        )
        self._http = requests.Session()
        adapter = HTTPAdapter(pool_connections=4, pool_maxsize=4, max_retries=0)
        self._http.mount("https://", adapter)
        self._http.mount("http://", adapter)
        self._http.headers.update({"User-Agent": self.config.USER_AGENT})

    def close(self) -> None:
        self.cache.close()
        self._http.close()

    # ------------------------------------------------------------------
    # TIER 1: OFFLINE MATH & LOGIC (SYMPY)
    # ------------------------------------------------------------------
    def _verify_math_sympy(self, question: str, subject_answer: str) -> Optional[FactCheckResult]:
        t0 = time.perf_counter()
        converted = _words_to_numbers(question)
        expr_candidate = _RE_WHITESPACE.sub(
            " ", _RE_MATH_LEAD_IN.sub(" ", converted).replace("?", " ")
        ).strip()

        # Case A: Percentage pattern like "15 % of 200"
        pct_match = _RE_PCT_PATTERN.search(converted)
        if pct_match:
            pct_val = float(pct_match.group(1))
            base_val = float(pct_match.group(2))
            return self._compare_math_numeric(
                expected=(pct_val / 100.0) * base_val,
                expr_display=f"{pct_val}% of {base_val}",
                subject_answer=subject_answer,
                keywords=_extract_keywords(question),
                t0=t0,
            )

        # Case B: Equality / Comparison claim ("Is 1 + 1 = 2?", "Is 2 + 2 = 5?")
        comp_match = _RE_COMP_PATTERN.search(expr_candidate)
        if comp_match:
            lhs_raw, op, rhs_raw = (
                comp_match.group(1).strip(),
                comp_match.group(2),
                comp_match.group(3).strip(),
            )
            lhs_val = _safe_sympy_eval(lhs_raw)
            rhs_val = _safe_sympy_eval(rhs_raw)
            if lhs_val is not None and rhs_val is not None:
                if op in ("=", "=="):
                    stmt_true = abs(lhs_val - rhs_val) < 1e-6
                elif op == "!=":
                    stmt_true = abs(lhs_val - rhs_val) >= 1e-6
                elif op == ">":
                    stmt_true = lhs_val > rhs_val
                elif op == "<":
                    stmt_true = lhs_val < rhs_val
                elif op == ">=":
                    stmt_true = lhs_val >= rhs_val - 1e-9
                else:
                    stmt_true = lhs_val <= rhs_val + 1e-9

                yn = _parse_yes_no(subject_answer)
                ans_num = _extract_numeric_value(subject_answer)
                expected_str = self._fmt_num(lhs_val)
                rhs_str = self._fmt_num(rhs_val)

                if yn is not None:
                    verdict = "TRUE" if (yn == stmt_true) else "FALSE"
                    summary = (
                        f"{lhs_raw} = {expected_str} (statement '{lhs_raw} {op} {rhs_str}' is "
                        f"{'TRUE' if stmt_true else 'FALSE'}; subject answered '{subject_answer}')."
                    )
                elif ans_num is not None:
                    verdict = "TRUE" if abs(ans_num - lhs_val) < 1e-6 else "FALSE"
                    summary = f"{lhs_raw} = {expected_str} (subject answered {self._fmt_num(ans_num)})."
                else:
                    verdict = "UNVERIFIABLE"
                    summary = f"Evaluated {lhs_raw} = {expected_str}, but could not parse subject answer '{subject_answer}'."

                return FactCheckResult(
                    is_objective=True,
                    topic="mathematics",
                    related_keywords=_extract_keywords(question) or ["math"],
                    factual_verdict=verdict,
                    factual_confidence=1.0 if verdict in ("TRUE", "FALSE") else 0.0,
                    correct_fact_summary=summary,
                    verification_source="sympy",
                    sources=["local:sympy"],
                    latency_ms=(time.perf_counter() - t0) * 1000.0,
                )

        # Case C: Direct arithmetic expression ("What is 1 + 1?", "What is 12 * 12?")
        expr_match = _RE_EXPR_PATTERN.search(expr_candidate)
        if expr_match:
            raw_expr = expr_match.group(0).strip()
            expected = _safe_sympy_eval(raw_expr)
            if expected is not None:
                return self._compare_math_numeric(
                    expected=expected,
                    expr_display=raw_expr,
                    subject_answer=subject_answer,
                    keywords=_extract_keywords(question),
                    t0=t0,
                )

        return None

    @staticmethod
    def _fmt_num(val: float) -> str:
        if abs(val - round(val)) < 1e-9:
            return str(int(round(val)))
        return f"{val:.4f}".rstrip("0").rstrip(".")

    def _compare_math_numeric(
        self,
        expected: float,
        expr_display: str,
        subject_answer: str,
        keywords: List[str],
        t0: float,
    ) -> FactCheckResult:
        ans_num = _extract_numeric_value(subject_answer)
        expected_str = self._fmt_num(expected)
        if ans_num is None:
            return FactCheckResult(
                is_objective=True,
                topic="mathematics",
                related_keywords=keywords or ["math"],
                factual_verdict="UNVERIFIABLE",
                factual_confidence=0.0,
                correct_fact_summary=f"{expr_display} = {expected_str} (could not parse numeric answer from '{subject_answer}').",
                verification_source="sympy",
                sources=["local:sympy"],
                latency_ms=(time.perf_counter() - t0) * 1000.0,
            )

        verdict = "TRUE" if abs(ans_num - expected) < 1e-6 else "FALSE"
        summary = f"{expr_display} = {expected_str} (subject answered {self._fmt_num(ans_num)})."
        return FactCheckResult(
            is_objective=True,
            topic="mathematics",
            related_keywords=keywords or ["math"],
            factual_verdict=verdict,
            factual_confidence=1.0,
            correct_fact_summary=summary,
            verification_source="sympy",
            sources=["local:sympy"],
            latency_ms=(time.perf_counter() - t0) * 1000.0,
        )

    # ------------------------------------------------------------------
    # TIER 2: KEYLESS WEB LOOKUPS (Wikipedia -> DDG IA -> ddgs)
    # ------------------------------------------------------------------
    @staticmethod
    def _build_search_query(question: str) -> str:
        q = question.strip().rstrip("?!.")
        q = _RE_QUERY_PREFIX.sub("", q)
        return q.strip() or question.strip()

    def _lookup_wikipedia(self, query: str) -> Tuple[List[str], List[str]]:
        snippets: List[str] = []
        sources: List[str] = []
        timeout = self.config.WEB_TIMEOUT_SEC
        try:
            resp = self._http.get(
                "https://en.wikipedia.org/w/api.php",
                params={
                    "action": "query",
                    "list": "search",
                    "srsearch": query,
                    "format": "json",
                    "srlimit": 3,
                    "utf8": 1,
                },
                timeout=timeout,
            )
            resp.raise_for_status()
            hits = resp.json().get("query", {}).get("search", [])
            if not hits:
                return snippets, sources

            top_title = hits[0].get("title", "")
            if top_title:
                safe_title = requests.utils.quote(top_title.replace(" ", "_"))
                sum_resp = self._http.get(
                    f"https://en.wikipedia.org/api/rest_v1/page/summary/{safe_title}",
                    timeout=timeout,
                )
                if sum_resp.status_code == 200:
                    sum_data = sum_resp.json()
                    extract = sum_data.get("extract", "").strip()
                    page_url = (
                        sum_data.get("content_urls", {})
                        .get("desktop", {})
                        .get("page", f"https://en.wikipedia.org/wiki/{safe_title}")
                    )
                    if extract:
                        snippets.append(extract)
                        sources.append(page_url)

            for hit in hits:
                raw_snip = _RE_HTML_TAG.sub("", hit.get("snippet", "")).strip()
                if raw_snip:
                    snippets.append(f"{hit.get('title', '')}: {raw_snip}")
        except Exception:
            pass
        return snippets, sources

    def _lookup_duckduckgo_ia(self, query: str) -> Tuple[List[str], List[str]]:
        snippets: List[str] = []
        sources: List[str] = []
        try:
            resp = self._http.get(
                "https://api.duckduckgo.com/",
                params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
                timeout=self.config.WEB_TIMEOUT_SEC,
            )
            resp.raise_for_status()
            data = resp.json()
            for field_name in ("Answer", "AbstractText", "Definition"):
                val = (data.get(field_name) or "").strip()
                if val:
                    snippets.append(val)
            abstract_url = (data.get("AbstractURL") or "").strip()
            if abstract_url:
                sources.append(abstract_url)
            for topic in (data.get("RelatedTopics") or [])[:3]:
                if isinstance(topic, dict) and topic.get("Text"):
                    snippets.append(topic["Text"].strip())
                    if topic.get("FirstURL") and len(sources) < 3:
                        sources.append(topic["FirstURL"])
        except Exception:
            pass
        return snippets, sources

    def _lookup_ddgs(self, query: str) -> Tuple[List[str], List[str]]:
        snippets: List[str] = []
        sources: List[str] = []
        if not HAS_DDGS:
            return snippets, sources
        try:
            with DDGS(timeout=int(max(2, round(self.config.WEB_TIMEOUT_SEC)))) as ddgs:
                results = ddgs.text(query, max_results=4)
                for r in results or []:
                    body = (r.get("body") or r.get("snippet") or "").strip()
                    title = (r.get("title") or "").strip()
                    href = (r.get("href") or r.get("link") or "").strip()
                    if body:
                        snippets.append(f"{title}: {body}" if title else body)
                    if href:
                        sources.append(href)
        except Exception:
            pass
        return snippets, sources

    def _fetch_web_evidence(self, question: str) -> Tuple[List[str], List[str], str]:
        """Two-tier cached web lookup with early exit on strong Wikipedia summary."""
        search_q = self._build_search_query(question)

        cached = self.cache.get(search_q)
        if cached:
            return (
                cached.get("snippets", []),
                cached.get("sources", []),
                cached.get("source", "wikipedia"),
            )

        if not self.config.ENABLE_WEB_LOOKUP:
            return [], [], "offline_fallback"

        all_snippets: List[str] = []
        all_sources: List[str] = []
        primary_source = "offline_fallback"

        # 2a. Wikipedia REST / MediaWiki API (fast, reliable, keyless)
        wiki_snips, wiki_srcs = self._lookup_wikipedia(search_q)
        if wiki_snips:
            all_snippets.extend(wiki_snips)
            all_sources.extend(wiki_srcs)
            primary_source = "wikipedia"

        # Early-exit optimization: skip extra HTTP roundtrips if Wikipedia returned a rich summary
        if len(all_snippets) < 2:
            ddg_snips, ddg_srcs = self._lookup_duckduckgo_ia(search_q)
            if ddg_snips:
                all_snippets.extend(ddg_snips)
                all_sources.extend(ddg_srcs)
                if primary_source == "offline_fallback":
                    primary_source = "duckduckgo_ia"

        if len(all_snippets) < 2:
            web_snips, web_srcs = self._lookup_ddgs(search_q)
            if web_snips:
                all_snippets.extend(web_snips)
                all_sources.extend(web_srcs)
                if primary_source == "offline_fallback":
                    primary_source = "ddgs"

        dedup_sources = list(dict.fromkeys(all_sources))[:5]
        if all_snippets:
            self.cache.set(
                search_q,
                primary_source,
                {"snippets": all_snippets[:6], "sources": dedup_sources},
            )
        return all_snippets[:6], dedup_sources, primary_source

    # ------------------------------------------------------------------
    # TIER 3: LOCAL ANSWER-VS-EVIDENCE VERIFIER (+ OPTIONAL OLLAMA HOOK)
    # ------------------------------------------------------------------
    def _verify_against_evidence_local(
        self,
        question: str,
        subject_answer: str,
        snippets: List[str],
    ) -> Tuple[str, float, str]:
        if not snippets:
            return (
                "UNVERIFIABLE",
                0.0,
                "No web evidence available (offline or lookup returned no results).",
            )

        sentences: List[str] = []
        for s in snippets:
            for sent in _RE_SENT_SPLIT.split(s):
                sent = sent.strip()
                if len(sent) >= 12:
                    sentences.append(sent)
        if not sentences:
            sentences = snippets

        q_sims = _tfidf_cosine_scores(question, sentences)
        ranked_idx = sorted(range(len(sentences)), key=lambda i: q_sims[i], reverse=True)
        top_sentences = [sentences[i] for i in ranked_idx[:3]]
        best_evidence = top_sentences[0]
        evidence_blob = " ".join(top_sentences)
        evidence_lower = evidence_blob.lower()

        ans_clean = subject_answer.strip()
        ans_keywords = _extract_keywords(ans_clean)

        # A. Yes/No question verification
        yn = _parse_yes_no(ans_clean)
        if yn is not None and _RE_YN_QUESTION.match(question):
            neg_cues = _RE_NEG_CUES.findall(evidence_lower)
            q_overlap = _fuzzy_ratio(question, evidence_blob)
            if q_overlap >= 0.45:
                evidence_supports_affirmative = len(neg_cues) == 0
                conf = min(0.85, 0.55 + 0.35 * q_overlap)
                return ("TRUE" if (yn == evidence_supports_affirmative) else "FALSE"), round(conf, 3), best_evidence[:260]
            return "UNVERIFIABLE", 0.25, best_evidence[:260]

        # B. Numeric / Year verification
        ans_num = _extract_numeric_value(ans_clean)
        ev_nums = [float(x) for x in _RE_FLOAT_TOKEN.findall(evidence_blob)]
        if ans_num is not None and ev_nums:
            if any(abs(ans_num - n) < 1e-4 for n in ev_nums):
                return "TRUE", 0.90, best_evidence[:260]
            if _RE_NUMERIC_Q.search(question):
                return "FALSE", 0.82, best_evidence[:260]

        # C. Direct entity / fuzzy + TF-IDF + negation verification
        direct_hit = bool(ans_keywords) and all(k in evidence_lower for k in ans_keywords)
        fuzzy_best = max(_fuzzy_ratio(ans_clean, s) for s in top_sentences)
        qa_sims = _tfidf_cosine_scores(f"{question} {ans_clean}", top_sentences)
        tfidf_best = max(qa_sims) if qa_sims else 0.0

        if ans_keywords:
            anchor = re.escape(ans_keywords[0])
            if re.search(rf"\b(not|never|instead of|rather than)\s+(?:\w+\s+){{0,3}}{anchor}\b", evidence_lower):
                return "FALSE", 0.82, best_evidence[:260]

        if direct_hit or fuzzy_best >= 0.72:
            conf = min(0.95, max(0.75, 0.60 + 0.35 * fuzzy_best))
            return "TRUE", round(conf, 3), best_evidence[:260]

        top_q_sim = q_sims[ranked_idx[0]] if ranked_idx else 0.0
        q_kw = _extract_keywords(question)
        q_kw_ratio = sum(1 for k in q_kw if k in evidence_lower) / max(1, len(q_kw))

        if (top_q_sim >= 0.20 or q_kw_ratio >= 0.55) and fuzzy_best < 0.45 and tfidf_best < 0.55:
            conf = min(0.85, 0.55 + 0.30 * max(top_q_sim, q_kw_ratio))
            return "FALSE", round(conf, 3), best_evidence[:260]

        return "UNVERIFIABLE", round(max(0.2, fuzzy_best * 0.5), 3), best_evidence[:260]

    def _refine_with_local_ollama(
        self,
        question: str,
        subject_answer: str,
        evidence_summary: str,
    ) -> Optional[Tuple[str, float, str]]:
        """Optional local Ollama tiny-LLM verifier (OFF by default; auto-falls back on error)."""
        if not self.config.USE_LOCAL_OLLAMA:
            return None

        prompt = (
            "You are a strict fact-checking judge. Compare the Subject Answer to the Evidence.\n"
            f"Question: {question}\n"
            f"Subject Answer: {subject_answer}\n"
            f"Evidence: {evidence_summary}\n"
            'Respond ONLY in valid JSON: {"verdict": "TRUE|FALSE|UNVERIFIABLE", "confidence": 0.0-1.0, "summary": "short ground truth"}'
        )
        try:
            resp = self._http.post(
                self.config.OLLAMA_URL,
                json={
                    "model": self.config.OLLAMA_MODEL,
                    "prompt": prompt,
                    "stream": False,
                    "format": "json",
                },
                timeout=self.config.OLLAMA_TIMEOUT_SEC,
            )
            resp.raise_for_status()
            parsed = json.loads(resp.json().get("response", "").strip())
            verdict = str(parsed.get("verdict", "UNVERIFIABLE")).upper()
            if verdict not in ("TRUE", "FALSE", "UNVERIFIABLE"):
                return None
            conf = max(0.0, min(1.0, float(parsed.get("confidence", 0.7))))
            summary = str(parsed.get("summary", evidence_summary)).strip() or evidence_summary
            return verdict, conf, summary[:260]
        except Exception:
            return None

    def check(self, question: str, subject_answer: str) -> FactCheckResult:
        t0 = time.perf_counter()
        is_objective, topic, keywords = self.classifier.classify(question, subject_answer)

        if not is_objective:
            return FactCheckResult(
                is_objective=False,
                topic=topic,
                related_keywords=keywords,
                factual_verdict="SUBJECTIVE",
                factual_confidence=0.0,
                correct_fact_summary="Subjective/personal question — evaluated via physiological sensors.",
                verification_source="none",
                sources=[],
                latency_ms=(time.perf_counter() - t0) * 1000.0,
            )

        if topic == "mathematics":
            math_res = self._verify_math_sympy(question, subject_answer)
            if math_res is not None:
                return math_res

        snippets, sources, v_source = self._fetch_web_evidence(question)
        verdict, conf, summary = self._verify_against_evidence_local(
            question, subject_answer, snippets
        )

        if self.config.USE_LOCAL_OLLAMA and snippets and (verdict == "UNVERIFIABLE" or conf < 0.75):
            refined = self._refine_with_local_ollama(question, subject_answer, " ".join(snippets[:2])[:600])
            if refined is not None:
                verdict, conf, summary = refined
                v_source = "ollama_refined"

        return FactCheckResult(
            is_objective=True,
            topic=topic,
            related_keywords=keywords,
            factual_verdict=verdict,
            factual_confidence=conf,
            correct_fact_summary=summary,
            verification_source=v_source,
            sources=sources,
            latency_ms=(time.perf_counter() - t0) * 1000.0,
        )


# =============================================================================
# 4. SESSION-BASED DOMAIN CREDIBILITY TRACKER (DYNAMIC DECEPTION PRIOR)
# =============================================================================
@dataclass
class DomainStats:
    domain: str
    credibility_score: float = 0.0  # -1.0 (unreliable) .. +1.0 (reliable)
    truths: int = 0
    lies: int = 0
    unverifiable: int = 0
    keywords_seen: List[str] = field(default_factory=list)
    last_updated: float = field(default_factory=time.time)


class DomainCredibilityTracker:
    """Tracks per-domain and global subject credibility within an interrogation session."""

    def __init__(self, config: Optional[FactCredibilityConfig] = None) -> None:
        self.config = config or FactCredibilityConfig()
        self._lock = threading.Lock()
        self._domains: Dict[str, DomainStats] = {}
        self._global_score: float = 0.0

    def reset(self) -> None:
        with self._lock:
            self._domains.clear()
            self._global_score = 0.0

    def get_prior_modifier(self, topic: str) -> Tuple[float, float, float, float, str]:
        with self._lock:
            stats = self._domains.get(topic)
            d_score = stats.credibility_score if stats else 0.0
            g_score = self._global_score

        if d_score < 0.0:
            domain_bias = abs(d_score) * self.config.MAX_DOMAIN_DECEPTION_BIAS
        else:
            domain_bias = -d_score * self.config.MAX_DOMAIN_TRUST_RELIEF

        global_bias = -g_score * self.config.GLOBAL_CREDIBILITY_WEIGHT
        total_bias = domain_bias + global_bias

        if stats and (stats.lies > 0 or stats.truths > 0):
            note = (
                f"{topic} reliability: {_clean_zero(d_score * 100):+.1f}% "
                f"(prior deception bias: {_clean_zero(total_bias * 100):+.1f}%, "
                f"history: {stats.truths}T/{stats.lies}L)"
            )
        elif abs(global_bias) >= 0.005:
            note = (
                f"{topic} reliability: neutral (0.0%), "
                f"global honesty prior: {_clean_zero(global_bias * 100):+.1f}%"
            )
        else:
            note = f"{topic} reliability: neutral (no prior bias)"

        return d_score, domain_bias, global_bias, total_bias, note

    def record_outcome(
        self,
        topic: str,
        factual_verdict: str,
        factual_confidence: float,
        keywords: List[str],
    ) -> float:
        with self._lock:
            if topic not in self._domains:
                self._domains[topic] = DomainStats(domain=topic)
            stats = self._domains[topic]

            for kw in keywords:
                if kw not in stats.keywords_seen:
                    stats.keywords_seen.append(kw)
            if len(stats.keywords_seen) > 20:
                stats.keywords_seen = stats.keywords_seen[-20:]

            conf = max(0.0, min(1.0, factual_confidence))

            if factual_verdict == "FALSE":
                step = (
                    self.config.BASE_LIE_PENALTY
                    * (self.config.LIE_COMPOUND_FACTOR ** min(stats.lies, 4))
                    * max(0.5, conf)
                )
                stats.credibility_score = max(-1.0, stats.credibility_score - step)
                stats.lies += 1
                self._global_score = max(-1.0, self._global_score - 0.18 * max(0.5, conf))
            elif factual_verdict == "TRUE":
                step = self.config.TRUTH_RECOVERY_STEP * max(0.5, conf)
                stats.credibility_score = min(1.0, stats.credibility_score + step)
                stats.truths += 1
                self._global_score = min(1.0, self._global_score + 0.08 * max(0.5, conf))
            else:
                stats.unverifiable += 1

            stats.last_updated = time.time()
            return stats.credibility_score

    def get_domain_table(self) -> List[Dict[str, Any]]:
        with self._lock:
            rows = []
            for name, st in sorted(self._domains.items()):
                if st.credibility_score <= -0.30:
                    status = "UNRELIABLE"
                elif st.credibility_score >= 0.25:
                    status = "RELIABLE"
                else:
                    status = "NEUTRAL"

                bias = (
                    abs(st.credibility_score) * self.config.MAX_DOMAIN_DECEPTION_BIAS
                    if st.credibility_score < 0
                    else -st.credibility_score * self.config.MAX_DOMAIN_TRUST_RELIEF
                )
                rows.append(
                    {
                        "domain": name,
                        "reliability_pct": _clean_zero(st.credibility_score * 100.0),
                        "active_deception_bias_pct": _clean_zero(bias * 100.0),
                        "truths": st.truths,
                        "lies": st.lies,
                        "unverifiable": st.unverifiable,
                        "status": status,
                    }
                )
            return rows


# =============================================================================
# 5. FUSED DECEPTION METER / TRUTH SCORE ENGINE
# =============================================================================
class FactCredibilityEngine:
    """Combines Physiological ML Score + Tiered Factual Verification + Domain Credibility."""

    def __init__(self, config: Optional[FactCredibilityConfig] = None) -> None:
        self.config = config or FactCredibilityConfig()
        self.fact_checker = KeylessFactChecker(self.config)
        self.tracker = DomainCredibilityTracker(self.config)

    def reset_session(self) -> None:
        self.tracker.reset()

    def close(self) -> None:
        self.fact_checker.close()

    def fuse(
        self,
        question: str,
        subject_answer: str,
        fact_check: FactCheckResult,
        physio_deception_prob: float,
    ) -> FusedEvaluationResult:
        """Unified fusion core used by both sync evaluation and background workers."""
        p_physio = physio_deception_prob / 100.0 if physio_deception_prob > 1.0 else physio_deception_prob
        p_physio = max(0.0, min(1.0, float(p_physio)))

        d_before, d_bias, g_bias, total_bias, cred_note = self.tracker.get_prior_modifier(
            fact_check.topic
        )

        factual_deception_prob: Optional[float] = None
        if fact_check.is_objective and fact_check.factual_verdict in ("TRUE", "FALSE"):
            if fact_check.factual_verdict == "FALSE":
                factual_deception_prob = 0.5 + 0.5 * fact_check.factual_confidence
            else:
                factual_deception_prob = 0.5 - 0.5 * fact_check.factual_confidence

            base_fused = (
                self.config.WEIGHT_PHYSIO_OBJECTIVE * p_physio
                + self.config.WEIGHT_FACTUAL_OBJECTIVE * factual_deception_prob
            )
            final_deception_prob = base_fused + total_bias
        else:
            final_deception_prob = (
                self.config.WEIGHT_PHYSIO_SUBJECTIVE * p_physio + total_bias
            )

        final_deception_prob = max(0.0, min(1.0, final_deception_prob))
        final_deception_pct = _clean_zero(final_deception_prob * 100.0)
        final_truth_pct = _clean_zero(100.0 - final_deception_pct)

        if final_deception_pct >= self.config.DECEPTION_HIGH_THRESHOLD:
            final_verdict = "DECEPTION DETECTED (LIE)"
        elif final_deception_pct >= self.config.DECEPTION_MED_THRESHOLD:
            final_verdict = "INCONCLUSIVE / ELEVATED SUSPICION"
        else:
            final_verdict = "TRUTHFUL RESPONSE"

        d_after = self.tracker.record_outcome(
            topic=fact_check.topic,
            factual_verdict=fact_check.factual_verdict,
            factual_confidence=fact_check.factual_confidence,
            keywords=fact_check.related_keywords,
        )

        result = FusedEvaluationResult(
            question=question,
            subject_answer=subject_answer,
            fact_check=fact_check,
            physio_deception_pct=_clean_zero(p_physio * 100.0),
            factual_deception_pct=(
                _clean_zero(factual_deception_prob * 100.0)
                if factual_deception_prob is not None
                else None
            ),
            domain_credibility_before=_clean_zero(d_before * 100.0),
            domain_credibility_after=_clean_zero(d_after * 100.0),
            domain_bias_pct=_clean_zero(d_bias * 100.0),
            global_bias_pct=_clean_zero(g_bias * 100.0),
            total_credibility_bias_pct=_clean_zero(total_bias * 100.0),
            credibility_note=cred_note,
            final_deception_pct=final_deception_pct,
            final_truth_pct=final_truth_pct,
            final_verdict=final_verdict,
            domain_table=self.tracker.get_domain_table(),
        )

        if self.config.LOG_SESSIONS:
            self._append_session_log(result)

        return result

    def evaluate(
        self,
        question: str,
        subject_answer: str,
        physio_deception_prob: float,
    ) -> FusedEvaluationResult:
        fc = self.fact_checker.check(question, subject_answer)
        return self.fuse(question, subject_answer, fc, physio_deception_prob)

    def _append_session_log(self, result: FusedEvaluationResult) -> None:
        try:
            self.config.SESSION_LOG_DIR.mkdir(parents=True, exist_ok=True)
            log_file = self.config.SESSION_LOG_DIR / "session_credibility.jsonl"
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(result.to_dict()) + "\n")
        except Exception:
            pass


# =============================================================================
# 6. NON-BLOCKING BACKGROUND WORKER FOR REAL-TIME SENSOR LOOPS
# =============================================================================
class AsyncFactCheckWorker:
    """
    Runs fact-checking & credibility fusion on a background worker thread so
    high-frequency sensor sampling loops (100–500 Hz on Raspberry Pi 4B) never block.
    """

    def __init__(self, engine: Optional[FactCredibilityEngine] = None, max_workers: int = 1) -> None:
        self.engine = engine or FactCredibilityEngine()
        self._executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=max_workers, thread_name_prefix="fact_worker"
        )
        self._completed: "queue.Queue[FusedEvaluationResult]" = queue.Queue()

    def submit_evaluation(
        self,
        question: str,
        subject_answer: str,
        physio_deception_prob: float,
    ) -> concurrent.futures.Future:
        def _task() -> FusedEvaluationResult:
            res = self.engine.evaluate(question, subject_answer, physio_deception_prob)
            self._completed.put(res)
            return res

        return self._executor.submit(_task)

    def submit_fact_check_only(self, question: str, subject_answer: str) -> concurrent.futures.Future:
        return self._executor.submit(self.engine.fact_checker.check, question, subject_answer)

    def fuse_prechecked(
        self,
        question: str,
        subject_answer: str,
        fact_check: FactCheckResult,
        physio_deception_prob: float,
    ) -> FusedEvaluationResult:
        return self.engine.fuse(question, subject_answer, fact_check, physio_deception_prob)

    def poll_completed(self) -> List[FusedEvaluationResult]:
        results: List[FusedEvaluationResult] = []
        while True:
            try:
                results.append(self._completed.get_nowait())
            except queue.Empty:
                break
        return results

    def shutdown(self) -> None:
        self._executor.shutdown(wait=False, cancel_futures=True)
        self.engine.close()


def format_credibility_table(domain_table: List[Dict[str, Any]]) -> str:
    """Formats the per-domain credibility table cleanly for terminal display."""
    if not domain_table:
        return "  (No domain credibility history recorded yet.)"
    header = (
        f"  {'Domain':<18} | {'Reliability':>11} | {'Decep. Bias':>11} | "
        f"{'T / L / U':>9} | {'Status':<10}"
    )
    sep = "  " + "-" * (len(header) - 2)
    lines = [header, sep]
    for row in domain_table:
        tlu = f"{row['truths']}/{row['lies']}/{row['unverifiable']}"
        lines.append(
            f"  {row['domain']:<18} | {row['reliability_pct']:+10.1f}% | "
            f"{row['active_deception_bias_pct']:+10.1f}% | {tlu:>9} | {row['status']:<10}"
        )
    return "\n".join(lines)
