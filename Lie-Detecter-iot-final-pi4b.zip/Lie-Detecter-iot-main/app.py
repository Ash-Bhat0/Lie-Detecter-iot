#!/usr/bin/env python3
"""
Combined Launcher for IoT Polygraph & Physiological Lie Detector (Pi 4B Optimized)
==================================================================================
Platform: Raspberry Pi 4 Model B / PC Cross-Platform Mode

Modes:
  1. Live Sensor Hardware Monitor (Raw ADC / VU Meter + non-blocking fact hook)
  2. Record New Training Session (Interrogation protocol with ground-truth labels)
  3. Train / Retrain Edge ML Models (Random Forest, SVM, Gradient Boosting)
  4. Run Real-Time ML Lie Detector (Fused Physiological ML + Keyless Fact-Checking)
  5. Generate Benchmark Synthetic Dataset (18 subjects with physiological responses)
  6. LIAR-PLUS NLP Claim Classifier Status (Text analysis direction)
  7. Fact-Check & Domain Credibility Console (Interactive CLI Evaluator)
  8. Launch Local Web Dashboard & JSON API (Zero-dependency Pi 4B Web UI)
  9. Exit

CLI Shortcuts:
  python app.py --web [--host 0.0.0.0] [--port 8080]
"""

import argparse
import json
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HARDWARE_SCRIPT = ROOT / "polygraph_pi4b.py"
MAX_REQUEST_BODY_BYTES = 64 * 1024  # 64 KB safety cap for Pi RAM


# =============================================================================
# EXISTING MODES (1 - 6) PRESERVED INTACT
# =============================================================================
def run_hardware_monitor():
    """Runs the direct hardware VU meter and buzzer monitor."""
    print("\n--- Starting Raw Sensor Hardware Monitor ---")
    if not HARDWARE_SCRIPT.exists():
        print(f"Error: Sensor script not found at {HARDWARE_SCRIPT}")
        return
    subprocess.run([sys.executable, str(HARDWARE_SCRIPT)], cwd=str(ROOT))


def run_data_collection():
    """Launches the labeled interrogation session recorder."""
    print("\n--- Starting Labeled Sensor Data Collector ---")
    from ml.data_collector import run_data_collection_session
    run_data_collection_session()


def run_model_training():
    """Runs feature extraction on raw sessions and trains candidate ML models."""
    print("\n--- Running Edge ML Training & Cross-Validation Pipeline ---")
    from ml.train_model import train_and_evaluate
    train_and_evaluate()


def run_live_polygraph_ml():
    """Runs the live ML Lie Detector interrogation engine (fused with fact-checking)."""
    print("\n--- Launching Real-Time Fused ML Lie Detector ---")
    from ml.polygraph_ml import run_live_interrogation
    run_live_interrogation()


def run_benchmark_generator():
    """Generates synthetic physiological benchmark dataset."""
    print("\n--- Generating Benchmark Physiological Dataset ---")
    from ml.generate_synthetic_data import generate_benchmark_dataset
    generate_benchmark_dataset(num_subjects=18, questions_per_subject=10)


def show_nlp_status():
    """Displays information on the LIAR-PLUS text claim direction."""
    print("\n" + "=" * 65)
    print("        LIAR-PLUS TEXT CLAIM CLASSIFIER (NLP DIRECTION)")
    print("=" * 65)
    print("This mode is for the linguistic/text claim verification model.")
    print("Requirements before training the NLP neural network:")
    print("  1. LIAR-PLUS TSV files: train2.tsv, val2.tsv, test2.tsv")
    print("  2. GloVe 200d Word Embeddings: glove.6B.200d.txt")
    print("  3. GPU recommended for PyTorch ConvS2S / MultiHeadAttention training.")
    print("\nNote: For Raspberry Pi 4B, use Option 4, 7, or 8 to run the")
    print("lightweight, keyless Local Fact-Checking + Domain Credibility Engine")
    print("alongside the Physiological Sensor ML pipeline.")
    print("=" * 65)


# =============================================================================
# MODE 7: INTERACTIVE CLI FACT-CHECK & DOMAIN CREDIBILITY CONSOLE
# =============================================================================
def run_fact_credibility_console():
    """Interactive CLI mode to evaluate Question + Subject Answer + Physio Score."""
    from ml.fact_credibility_engine import FactCredibilityEngine, format_credibility_table

    engine = FactCredibilityEngine()
    print("\n" + "=" * 68)
    print("   LOCAL KEYLESS FACT-CHECK & DOMAIN CREDIBILITY CONSOLE (Pi 4B)")
    print("=" * 68)
    print("Enter questions and subject answers to see fused Truth/Deception")
    print("scores and live per-domain credibility shifts. Type 'reset' to clear")
    print("session history, or 'exit' to return to the main menu.")

    try:
        while True:
            print("\n" + "-" * 68)
            question = input("Question (or 'reset'/'exit'): ").strip()
            if not question:
                continue
            if question.lower() in ("exit", "quit", "q"):
                break
            if question.lower() == "reset":
                engine.reset_session()
                print("[Session Reset] All domain credibility scores cleared.")
                continue

            subject_answer = input("Subject Answer: ").strip()
            phys_raw = input("Physiological Deception % [0-100, default 30]: ").strip()
            try:
                phys_pct = float(phys_raw) if phys_raw else 30.0
            except ValueError:
                phys_pct = 30.0

            res = engine.evaluate(question, subject_answer, phys_pct)
            fc = res.fact_check

            meter_len = 30
            filled = int((res.final_deception_pct / 100.0) * meter_len)
            bar = "[" + "#" * filled + "-" * (meter_len - filled) + "]"

            print("\n" + "=" * 68)
            print(f"  FINAL VERDICT       : {res.final_verdict}")
            print(f"  Deception Meter     : {res.final_deception_pct:5.1f}%  {bar}")
            print(f"  Truth Score         : {res.final_truth_pct:5.1f}%")
            print("-" * 68)
            print(f"  Physiological Score : {res.physio_deception_pct:5.1f}% deception")
            print(
                f"  Classification      : topic={fc.topic} | "
                f"objective={'YES' if fc.is_objective else 'NO (Subjective)'}"
            )
            print(
                f"  Factual Verdict     : {fc.factual_verdict} "
                f"(conf={fc.factual_confidence:.2f}, tier={fc.verification_source}, {fc.latency_ms:.1f}ms)"
            )
            print(f"  Ground-Truth Info   : {fc.correct_fact_summary}")
            if fc.sources:
                print(f"  Sources             : {', '.join(fc.sources[:3])}")
            print(f"  Domain Credibility  : {res.credibility_note}")
            print("\n  Per-Domain Credibility Table:")
            print(format_credibility_table(res.domain_table))
            print("=" * 68)
    finally:
        engine.close()


# =============================================================================
# MODE 8: LIGHTWEIGHT LOCAL WEB DASHBOARD & JSON API (Zero Extra Dependencies)
# =============================================================================
_WEB_UI_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kinski IoT Polygraph — Fact &amp; Credibility Dashboard</title>
<style>
  :root {
    --bg: #0f172a; --card: #1e293b; --border: #334155;
    --text: #f8fafc; --muted: #94a3b8;
    --green: #22c55e; --amber: #f59e0b; --red: #ef4444; --blue: #38bdf8;
  }
  body { font-family: system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 24px; }
  .wrap { max-width: 960px; margin: 0 auto; }
  h1 { margin: 0 0 6px; font-size: 1.5rem; }
  .sub { color: var(--muted); margin: 0 0 20px; font-size: 0.92rem; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
  @media (max-width: 760px) { .grid { grid-template-columns: 1fr; } }
  .card { background: var(--card); border: 1px solid var(--border); border-radius: 10px; padding: 18px; }
  label { display: block; font-size: 0.85rem; color: var(--muted); margin-bottom: 5px; margin-top: 12px; }
  input[type="text"] {
    width: 100%; box-sizing: border-box; padding: 10px; border-radius: 6px;
    border: 1px solid var(--border); background: #0b1220; color: var(--text); font-size: 0.95rem;
  }
  input[type="range"] { width: 100%; }
  .row { display: flex; gap: 10px; margin-top: 16px; }
  button {
    padding: 10px 16px; border-radius: 6px; border: none; cursor: pointer;
    font-weight: 600; font-size: 0.92rem;
  }
  .btn-primary { background: var(--blue); color: #0f172a; flex: 1; }
  .btn-secondary { background: #334155; color: var(--text); }
  .meter-bg { width: 100%; height: 22px; background: #0b1220; border-radius: 999px; overflow: hidden; margin: 10px 0; border: 1px solid var(--border); }
  .meter-fill { height: 100%; width: 0%; transition: width 0.3s ease; background: var(--green); }
  .verdict { font-size: 1.15rem; font-weight: 700; margin-bottom: 6px; }
  .kv { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #263449; font-size: 0.9rem; gap: 12px; }
  .kv span:first-child { color: var(--muted); }
  .kv span:last-child { text-align: right; }
  table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 0.88rem; }
  th, td { text-align: left; padding: 8px 10px; border-bottom: 1px solid var(--border); }
  th { color: var(--muted); font-weight: 600; }
  .badge { padding: 2px 8px; border-radius: 999px; font-size: 0.78rem; font-weight: 600; }
  .UNRELIABLE { background: rgba(239,68,68,0.2); color: #fca5a5; }
  .RELIABLE { background: rgba(34,197,94,0.2); color: #86efac; }
  .NEUTRAL { background: rgba(148,163,184,0.2); color: #cbd5e1; }
</style>
</head>
<body>
<div class="wrap">
  <h1>Kinski IoT Polygraph — Fused Fact &amp; Domain Credibility</h1>
  <p class="sub">Raspberry Pi 4B Local &amp; Keyless Engine (SymPy + Wikipedia/DuckDuckGo + Physiological Fusion)</p>

  <div class="grid">
    <div class="card">
      <h3 style="margin-top:0">Evaluate Question &amp; Answer</h3>
      <label for="question">Question</label>
      <input id="question" type="text" placeholder="e.g., What is 1 + 1?" value="What is 1 + 1?" />

      <label for="answer">Subject Answer</label>
      <input id="answer" type="text" placeholder="e.g., 3" value="3" />

      <label for="physio">Physiological ML Deception Score: <strong id="physioVal">25%</strong></label>
      <input id="physio" type="range" min="0" max="100" value="25" oninput="document.getElementById('physioVal').textContent=this.value+'%'" />

      <div class="row">
        <button class="btn-primary" onclick="evaluateTrial()">Evaluate Trial</button>
        <button class="btn-secondary" onclick="resetSession()">Reset Session</button>
      </div>
    </div>

    <div class="card">
      <h3 style="margin-top:0">Fused Deception Meter &amp; Breakdown</h3>
      <div id="verdict" class="verdict">Awaiting trial...</div>
      <div class="meter-bg"><div id="meterFill" class="meter-fill"></div></div>
      <div class="kv"><span>Final Deception / Truth</span><span id="finalScores">--</span></div>
      <div class="kv"><span>Physiological Score</span><span id="physioScore">--</span></div>
      <div class="kv"><span>Topic &amp; Type</span><span id="topicInfo">--</span></div>
      <div class="kv"><span>Factual Verdict (Tier)</span><span id="factualInfo">--</span></div>
      <div class="kv"><span>Domain Credibility Mod.</span><span id="credMod">--</span></div>
      <div class="kv"><span>Ground-Truth Summary</span><span id="factSummary">--</span></div>
    </div>
  </div>

  <div class="card" style="margin-top:18px;">
    <h3 style="margin-top:0">Session Per-Domain Credibility Table</h3>
    <table>
      <thead>
        <tr>
          <th>Domain</th>
          <th>Reliability</th>
          <th>Active Deception Bias</th>
          <th>Truths / Lies / Unverif.</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody id="credTableBody">
        <tr><td colspan="5" style="color:#94a3b8;">No trials evaluated in this session yet.</td></tr>
      </tbody>
    </table>
  </div>
</div>

<script>
async function evaluateTrial() {
  const payload = {
    question: document.getElementById('question').value,
    answer: document.getElementById('answer').value,
    physio_deception_pct: parseFloat(document.getElementById('physio').value)
  };
  const resp = await fetch('/api/evaluate', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(payload)
  });
  const data = await resp.json();
  renderResult(data);
}

async function resetSession() {
  await fetch('/api/reset', {method: 'POST'});
  document.getElementById('verdict').textContent = 'Session reset. Awaiting trial...';
  document.getElementById('meterFill').style.width = '0%';
  renderTable([]);
}

function renderResult(d) {
  const fc = d.fact_check;
  const fill = document.getElementById('meterFill');
  fill.style.width = d.final_deception_pct + '%';
  fill.style.background = d.final_deception_pct >= 65 ? '#ef4444' : (d.final_deception_pct >= 45 ? '#f59e0b' : '#22c55e');

  document.getElementById('verdict').textContent = d.final_verdict;
  document.getElementById('finalScores').textContent = d.final_deception_pct + '% Deception / ' + d.final_truth_pct + '% Truth';
  document.getElementById('physioScore').textContent = d.physio_deception_pct + '%';
  document.getElementById('topicInfo').textContent = fc.topic + ' (' + (fc.is_objective ? 'Objective' : 'Subjective') + ')';
  document.getElementById('factualInfo').textContent = fc.factual_verdict + ' [' + fc.verification_source + ', conf=' + fc.factual_confidence + ']';
  document.getElementById('credMod').textContent = d.credibility_note;
  document.getElementById('factSummary').textContent = fc.correct_fact_summary;
  renderTable(d.domain_table || []);
}

function renderTable(rows) {
  const tbody = document.getElementById('credTableBody');
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="5" style="color:#94a3b8;">No trials evaluated in this session yet.</td></tr>';
    return;
  }
  tbody.innerHTML = rows.map(r => `
    <tr>
      <td><strong>${r.domain}</strong></td>
      <td>${r.reliability_pct > 0 ? '+' : ''}${r.reliability_pct}%</td>
      <td>${r.active_deception_bias_pct > 0 ? '+' : ''}${r.active_deception_bias_pct}%</td>
      <td>${r.truths} / ${r.lies} / ${r.unverifiable}</td>
      <td><span class="badge ${r.status}">${r.status}</span></td>
    </tr>
  `).join('');
}
</script>
</body>
</html>
"""


class ReusableThreadingHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def create_web_server(host: str = "0.0.0.0", port: int = 8080, engine=None):
    """Creates a lightweight stdlib HTTP server & JSON API (reusable for tests and production)."""
    if engine is None:
        from ml.fact_credibility_engine import FactCredibilityEngine

        engine = FactCredibilityEngine()

    class PolygraphHandler(BaseHTTPRequestHandler):
        def _send_json(self, payload: dict, status: int = 200):
            body = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _send_html(self, html: str, status: int = 200):
            body = html.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                self._send_html(_WEB_UI_HTML)
            elif self.path == "/api/credibility":
                self._send_json({"domain_table": engine.tracker.get_domain_table()})
            elif self.path == "/api/health":
                self._send_json(
                    {
                        "status": "ok",
                        "cached_facts": engine.fact_checker.cache.count(),
                        "domains_tracked": len(engine.tracker.get_domain_table()),
                    }
                )
            else:
                self._send_json({"error": "Not found"}, status=404)

        def do_POST(self):
            length = int(self.headers.get("Content-Length", "0"))
            if length > MAX_REQUEST_BODY_BYTES:
                self._send_json({"error": "Payload too large"}, status=413)
                return
            raw = self.rfile.read(length) if length > 0 else b"{}"
            try:
                data = json.loads(raw.decode("utf-8"))
            except Exception:
                self._send_json({"error": "Invalid JSON"}, status=400)
                return

            if self.path == "/api/evaluate":
                question = str(data.get("question", "")).strip()
                answer = str(data.get("answer", "")).strip()
                try:
                    physio = float(data.get("physio_deception_pct", 30.0))
                except (TypeError, ValueError):
                    physio = 30.0
                if not question:
                    self._send_json({"error": "Field 'question' is required."}, status=400)
                    return
                res = engine.evaluate(question, answer, physio)
                self._send_json(res.to_dict())
            elif self.path == "/api/reset":
                engine.reset_session()
                self._send_json({"status": "reset", "domain_table": []})
            else:
                self._send_json({"error": "Not found"}, status=404)

        def log_message(self, format, *args):
            return

    server = ReusableThreadingHTTPServer((host, port), PolygraphHandler)
    return server, engine


def run_web_dashboard(host: str = "0.0.0.0", port: int = 8080):
    server, engine = create_web_server(host=host, port=port)
    print(f"\n[Web Dashboard Running] Open http://localhost:{port} (or http://<pi-ip>:{port})")
    print("Endpoints: POST /api/evaluate | GET /api/credibility | GET /api/health | POST /api/reset")
    print("Press Ctrl+C to stop the web server and return.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nWeb server stopped.")
    finally:
        server.server_close()
        engine.close()


def main():
    parser = argparse.ArgumentParser(description="Kinski IoT Polygraph Launcher")
    parser.add_argument("--web", action="store_true", help="Launch local Web UI & JSON API directly")
    parser.add_argument("--host", default="0.0.0.0", help="Web server bind host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8080, help="Web server port (default: 8080)")
    args = parser.parse_args()

    if args.web:
        run_web_dashboard(host=args.host, port=args.port)
        return

    while True:
        print("\n" + "=" * 68)
        print("   KINSKI IOT POLYGRAPH & LIE DETECTION SYSTEM (Raspberry Pi 4B)")
        print("=" * 68)
        print("  1. Live Sensor Hardware Monitor (Raw Pulse/GSR + Live Fact Hook)")
        print("  2. Record New Training Session (Interrogation data logger)")
        print("  3. Train / Retrain Edge ML Models (Random Forest, SVM, GBM)")
        print("  4. Run Real-Time ML Lie Detector (Fused Physio ML + Fact Check)")
        print("  5. Generate / Refresh Benchmark Training Dataset")
        print("  6. LIAR-PLUS Text Claim Classifier (NLP Requirements)")
        print("  7. Fact-Check & Domain Credibility Console (Interactive CLI)")
        print("  8. Launch Local Web Dashboard & JSON API (http://0.0.0.0:8080)")
        print("  9. Exit")
        print("=" * 68)

        choice = input("Select an option (1-9): ").strip()
        if choice == "1":
            run_hardware_monitor()
        elif choice == "2":
            run_data_collection()
        elif choice == "3":
            run_model_training()
        elif choice == "4":
            run_live_polygraph_ml()
        elif choice == "5":
            run_benchmark_generator()
        elif choice == "6":
            show_nlp_status()
        elif choice == "7":
            run_fact_credibility_console()
        elif choice == "8":
            run_web_dashboard(host=args.host, port=args.port)
        elif choice == "9":
            print("\nExiting. Thank you!")
            break
        else:
            print("\n[Invalid Selection] Please choose a number between 1 and 9.")


if __name__ == "__main__":
    main()
