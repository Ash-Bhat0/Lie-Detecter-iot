#!/usr/bin/env python3
"""
Standalone Verification Suite for Local & Keyless Fact-Checking + Domain Credibility Engine
===========================================================================================
Simulates mocked physiological sensor scores and verifies:
  1. Offline Math Credibility Chain ("1 + 1 = 3" -> "2 + 2 = 4" -> "Is 2 + 2 = 5? yes")
     plus cross-domain isolation (switching mathematics -> geography).
  2. General-Knowledge Web Check + L1/L2 SQLite caching + graceful offline fallback.
  3. Subjective Personal Question ("Did you take the money?") falling back cleanly to physio.
  4. Non-Blocking AsyncFactCheckWorker submission timing (<10ms) for 500 Hz sensor loops.
  5. Local Web Dashboard JSON API (/api/health, /api/evaluate, /api/credibility, /api/reset).
"""

import json
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

from app import create_web_server
from ml.fact_credibility_engine import (
    AsyncFactCheckWorker,
    FactCredibilityConfig,
    FactCredibilityEngine,
    format_credibility_table,
)


def print_result(label: str, res) -> None:
    fc = res.fact_check
    print(f"\n[{label}]")
    print(f"  Q: {res.question}  |  Subject Answer: {res.subject_answer}")
    print(
        f"  Classification : topic={fc.topic}, objective={fc.is_objective}, "
        f"keywords={fc.related_keywords}"
    )
    print(
        f"  Fact-Check     : verdict={fc.factual_verdict} (conf={fc.factual_confidence:.2f}, "
        f"tier={fc.verification_source}, {fc.latency_ms:.1f}ms)"
    )
    print(f"  Fact Summary   : {fc.correct_fact_summary}")
    print(
        f"  Scores         : Physio={res.physio_deception_pct:.1f}% | "
        f"Factual={res.factual_deception_pct}% | "
        f"Domain Bias={res.domain_bias_pct:+.1f}% | Global Bias={res.global_bias_pct:+.1f}%"
    )
    print(
        f"  FINAL          : Deception={res.final_deception_pct:.1f}% | "
        f"Truth={res.final_truth_pct:.1f}% | Verdict={res.final_verdict}"
    )
    print(f"  Credibility    : {res.credibility_note}")


def test_1_math_credibility_chain() -> None:
    print("\n" + "=" * 74)
    print("TEST 1: OFFLINE MATH CREDIBILITY CHAIN (SymPy) & CROSS-DOMAIN ISOLATION")
    print("=" * 74)

    with tempfile.TemporaryDirectory() as tmpdir:
        cfg = FactCredibilityConfig(
            ENABLE_WEB_LOOKUP=False,
            CACHE_DB_PATH=Path(tmpdir) / "test_cache.db",
        )
        engine = FactCredibilityEngine(cfg)
        try:
            r1 = engine.evaluate("What is 1 + 1?", "3", physio_deception_prob=0.25)
            print_result("Q1: Math Lie (1 + 1 = 3)", r1)
            assert r1.fact_check.topic == "mathematics"
            assert r1.fact_check.verification_source == "sympy"
            assert r1.fact_check.factual_verdict == "FALSE"
            assert r1.final_deception_pct >= 70.0
            assert r1.domain_credibility_after < 0.0

            r2 = engine.evaluate("What is 2 + 2?", "4", physio_deception_prob=0.25)
            print_result("Q2: Math Follow-Up Truth (2 + 2 = 4) with Active Penalty", r2)
            assert r2.fact_check.topic == "mathematics"
            assert r2.fact_check.factual_verdict == "TRUE"
            assert r2.domain_bias_pct > 0.0
            assert r2.domain_credibility_after > r2.domain_credibility_before

            r3 = engine.evaluate("Is 2 + 2 = 5?", "yes", physio_deception_prob=0.30)
            print_result("Q3: Second Math Lie (Is 2 + 2 = 5? -> yes)", r3)
            assert r3.fact_check.factual_verdict == "FALSE"
            assert r3.domain_credibility_after < r2.domain_credibility_after

            r4 = engine.evaluate("What is the capital of France?", "Paris", physio_deception_prob=0.25)
            print_result("Q4: Unrelated Domain Switch (Geography)", r4)
            assert r4.fact_check.topic == "geography"
            assert r4.domain_bias_pct == 0.0
            assert abs(r4.global_bias_pct) <= 4.0

            print("\nPer-Domain Credibility Table after Test 1:")
            print(format_credibility_table(r4.domain_table))
            print("-> TEST 1 PASSED")
        finally:
            engine.close()


def test_2_web_check_and_offline_fallback() -> None:
    print("\n" + "=" * 74)
    print("TEST 2: GENERAL KNOWLEDGE WEB CHECK, L1/L2 CACHE & OFFLINE FALLBACK")
    print("=" * 74)

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "fact_cache.db"
        cfg_cached = FactCredibilityConfig(ENABLE_WEB_LOOKUP=False, CACHE_DB_PATH=db_path)
        engine = FactCredibilityEngine(cfg_cached)
        try:
            engine.fact_checker.cache.set(
                "the capital of France",
                "wikipedia",
                {
                    "snippets": [
                        "Paris is the capital and largest city of France, with an estimated population of over 2 million residents."
                    ],
                    "sources": ["https://en.wikipedia.org/wiki/Paris"],
                },
            )

            r_true = engine.evaluate("What is the capital of France?", "Paris", physio_deception_prob=0.20)
            print_result("2A: Cached Wikipedia Check (Correct Answer: Paris)", r_true)
            assert r_true.fact_check.factual_verdict == "TRUE"
            assert r_true.fact_check.verification_source == "wikipedia"

            r_false = engine.evaluate("What is the capital of France?", "Berlin", physio_deception_prob=0.20)
            print_result("2B: Cached Wikipedia Check (Wrong Answer: Berlin)", r_false)
            assert r_false.fact_check.factual_verdict == "FALSE"
            assert r_false.final_deception_pct > r_true.final_deception_pct

            r_offline = engine.evaluate(
                "Who won the Nobel Prize in Physics in 1921?",
                "Albert Einstein",
                physio_deception_prob=0.35,
            )
            print_result("2C: Graceful Offline Fallback (No Network)", r_offline)
            assert r_offline.fact_check.factual_verdict == "UNVERIFIABLE"
            assert r_offline.fact_check.verification_source == "offline_fallback"
            assert abs(r_offline.final_deception_pct - (35.0 + r_offline.total_credibility_bias_pct)) <= 0.5
        finally:
            engine.close()

        cfg_live = FactCredibilityConfig(
            ENABLE_WEB_LOOKUP=True,
            WEB_TIMEOUT_SEC=3.5,
            CACHE_DB_PATH=Path(tmpdir) / "live_cache.db",
        )
        live_engine = FactCredibilityEngine(cfg_live)
        try:
            r_live = live_engine.evaluate("What is the boiling point of water in Celsius?", "100", 0.25)
            print_result("2D: Live Keyless Web Probe (Graceful if Sandbox Offline)", r_live)
            assert r_live.fact_check.factual_verdict in ("TRUE", "FALSE", "UNVERIFIABLE")
            print("-> TEST 2 PASSED")
        finally:
            live_engine.close()


def test_3_subjective_personal_question() -> None:
    print("\n" + "=" * 74)
    print("TEST 3: SUBJECTIVE / PERSONAL QUESTION FALLBACK TO PHYSIOLOGICAL ML")
    print("=" * 74)

    with tempfile.TemporaryDirectory() as tmpdir:
        cfg = FactCredibilityConfig(
            ENABLE_WEB_LOOKUP=False,
            CACHE_DB_PATH=Path(tmpdir) / "subj_cache.db",
        )
        engine = FactCredibilityEngine(cfg)
        try:
            r_subj = engine.evaluate(
                "Did you take the money from the desk yesterday?",
                "No, I never touched it.",
                physio_deception_prob=0.82,
            )
            print_result("3A: Personal Question (High Physio Stress)", r_subj)
            assert r_subj.fact_check.is_objective is False
            assert r_subj.fact_check.topic == "personal"
            assert r_subj.fact_check.factual_verdict == "SUBJECTIVE"
            assert r_subj.fact_check.verification_source == "none"
            assert r_subj.final_deception_pct == 82.0
            assert r_subj.final_verdict == "DECEPTION DETECTED (LIE)"
            print("-> TEST 3 PASSED")
        finally:
            engine.close()


def test_4_non_blocking_background_worker() -> None:
    print("\n" + "=" * 74)
    print("TEST 4: NON-BLOCKING BACKGROUND WORKER TIMING (500 Hz SENSOR SAFE)")
    print("=" * 74)

    with tempfile.TemporaryDirectory() as tmpdir:
        cfg = FactCredibilityConfig(
            ENABLE_WEB_LOOKUP=False,
            CACHE_DB_PATH=Path(tmpdir) / "async_cache.db",
        )
        worker = AsyncFactCheckWorker(FactCredibilityEngine(cfg))
        try:
            t0 = time.perf_counter()
            fut = worker.submit_evaluation("What is 12 * 12?", "144", physio_deception_prob=0.18)
            submit_ms = (time.perf_counter() - t0) * 1000.0
            print(f"  Background submission latency: {submit_ms:.3f} ms")
            assert submit_ms < 25.0

            res = fut.result(timeout=3.0)
            polled = worker.poll_completed()
            assert len(polled) == 1
            assert res.fact_check.factual_verdict == "TRUE"
            assert res.final_truth_pct >= 80.0
            print(f"  Background worker completed: {res.final_verdict} (Truth: {res.final_truth_pct:.1f}%)")
            print("-> TEST 4 PASSED")
        finally:
            worker.shutdown()


def test_5_web_api_smoke() -> None:
    print("\n" + "=" * 74)
    print("TEST 5: LOCAL WEB DASHBOARD & JSON API SMOKE TEST")
    print("=" * 74)

    with tempfile.TemporaryDirectory() as tmpdir:
        cfg = FactCredibilityConfig(
            ENABLE_WEB_LOOKUP=False,
            CACHE_DB_PATH=Path(tmpdir) / "api_cache.db",
        )
        engine = FactCredibilityEngine(cfg)
        server, _ = create_web_server(host="127.0.0.1", port=0, engine=engine)
        port = server.server_address[1]
        t = threading.Thread(target=server.serve_forever, daemon=True)
        t.start()
        try:
            base = f"http://127.0.0.1:{port}"
            # Health check
            with urllib.request.urlopen(f"{base}/api/health", timeout=2) as r:
                health = json.loads(r.read().decode("utf-8"))
                assert health["status"] == "ok"

            # Evaluate 1+1=3 via POST /api/evaluate
            req = urllib.request.Request(
                f"{base}/api/evaluate",
                data=json.dumps({"question": "What is 1 + 1?", "answer": "3", "physio_deception_pct": 25}).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=2) as r:
                res = json.loads(r.read().decode("utf-8"))
                assert res["fact_check"]["factual_verdict"] == "FALSE"
                assert res["final_deception_pct"] >= 70.0

            # Credibility table endpoint
            with urllib.request.urlopen(f"{base}/api/credibility", timeout=2) as r:
                cred = json.loads(r.read().decode("utf-8"))
                assert len(cred["domain_table"]) == 1
                assert cred["domain_table"][0]["domain"] == "mathematics"

            # Reset endpoint
            req_reset = urllib.request.Request(f"{base}/api/reset", data=b"{}", method="POST")
            with urllib.request.urlopen(req_reset, timeout=2) as r:
                reset_data = json.loads(r.read().decode("utf-8"))
                assert reset_data["status"] == "reset"

            print(f"  Local HTTP API verified on ephemeral port {port} (/api/health, /api/evaluate, /api/credibility, /api/reset).")
            print("-> TEST 5 PASSED")
        finally:
            server.shutdown()
            server.server_close()
            engine.close()


if __name__ == "__main__":
    test_1_math_credibility_chain()
    test_2_web_check_and_offline_fallback()
    test_3_subjective_personal_question()
    test_4_non_blocking_background_worker()
    test_5_web_api_smoke()
    print("\n" + "=" * 74)
    print("ALL 5 VERIFICATION TESTS PASSED SUCCESSFULLY.")
    print("=" * 74)
